import { g as getDefaultExportFromCjs } from './index-HWN39uuG.js';
import { r as requireReactDom } from './index-C4_CXkXr.js';

var reactDomExports = requireReactDom();
const index = /*@__PURE__*/getDefaultExportFromCjs(reactDomExports);

export { index as default };
