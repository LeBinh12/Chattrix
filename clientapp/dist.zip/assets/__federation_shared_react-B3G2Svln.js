import { r as requireReact, g as getDefaultExportFromCjs } from './index-HWN39uuG.js';

var reactExports = requireReact();
const index = /*@__PURE__*/getDefaultExportFromCjs(reactExports);

export { index as default };
